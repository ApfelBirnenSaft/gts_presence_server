import datetime as DateTime
from enum import Enum
from typing import Optional

from .audit import *

class StudentAudit(db.Model):
    __tablename__ = 'students' + '_audit'

    audit_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    audit_action = db.Column(db.Enum(AuditAction), nullable=False)
    audit_datetime = db.Column(db.DateTime, nullable=False)
    audit_issuer_id = db.Column(db.Integer, nullable=True)

    id = db.Column(db.Integer, nullable=False)#, primary_key = True, nullable=False)
    last_change = db.Column(db.DateTime, nullable=False)
    
    first_name = db.Column(db.Text, nullable=False)
    last_name = db.Column(db.Text, nullable=False)
    grade = db.Column(db.Integer, nullable=False)
    class_id = db.Column(db.Text, nullable=False)

    monday_homework_room_id = db.Column(db.Integer, nullable=True)
    tuesday_homework_room_id = db.Column(db.Integer, nullable=True)
    wednesday_homework_room_id = db.Column(db.Integer, nullable=True)
    thursday_homework_room_id = db.Column(db.Integer, nullable=True)

    monday_school_club_id = db.Column(db.Integer, nullable=True)
    tuesday_school_club_id = db.Column(db.Integer, nullable=True)
    wednesday_school_club_id = db.Column(db.Integer, nullable=True)
    thursday_school_club_id = db.Column(db.Integer, nullable=True)

    def __init__(self, audit_id:int, audit_action:AuditAction, audit_datetime: DateTime, audit_issuer_id:Optional["int"], first_name:str, last_name:str, grade:int, class_id:str,
                 monday_homework_room_id:int, tuesday_homework_room_id:int, wednesday_homework_room_id:int, thursday_homework_room_id:int,
                 monday_school_club_id:int, tuesday_school_club_id:int, wednesday_school_club_id:int, thursday_school_club_id:int):
        self.audit_id = audit_id
        self.audit_action = audit_action
        self.audit_datetime = audit_datetime
        self.audit_issuer_id = audit_issuer_id

        self.first_name = first_name
        self.last_name = last_name
        self.grade = grade
        self.class_id = class_id

        self.monday_homework_room_id = monday_homework_room_id
        self.tuesday_homework_room_id = tuesday_homework_room_id
        self.wednesday_homework_room_id = wednesday_homework_room_id
        self.thursday_homework_room_id = thursday_homework_room_id

        self.monday_school_club_id = monday_school_club_id
        self.tuesday_school_club_id = tuesday_school_club_id
        self.wednesday_school_club_id = wednesday_school_club_id
        self.thursday_school_club_id = thursday_school_club_id

        self.last_change = DateTime.datetime.now()

    def __repr__(self):
        return f'<Student {self.id} {self.first_name} {self.last_name}>'

    def to_dict(self):
        return {
            'audit_id': self.audit_id,
            'audit_action': self.audit_action,
            'audit_datetime': self.audit_datetime,
            'audit_issuer_id': self.audit_issuer_id,

            'id': self.id,
            'first_name': self.first_name,
            'last_name': self.last_name,
            'grade': self.grade,
            'class_id': self.class_id,
            'monday_homework_room_id': self.monday_homework_room_id,
            'tuesday_homework_room_id': self.tuesday_homework_room_id,
            'wednesday_homework_room_id': self.wednesday_homework_room_id,
            'thursday_homework_room_id': self.thursday_homework_room_id,
            'monday_school_club_id': self.monday_school_club_id,
            'tuesday_school_club_id': self.tuesday_school_club_id,
            'wednesday_school_club_id': self.wednesday_school_club_id,
            'thursday_school_club_id': self.thursday_school_club_id,
        }



class StudentNoteAudit(db.Model):
    __tablename__ = "student_notes" + '_audit'

    audit_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    audit_action = db.Column(db.Enum(AuditAction), nullable=False)
    audit_datetime = db.Column(db.DateTime, nullable=False)
    audit_issuer_id = db.Column(db.Integer, nullable=True)
    
    id = db.Column(db.Integer, nullable=False)#, primary_key = True, nullable=False)
    datetime = db.Column(db.DateTime, nullable=False)
    issuer_id = db.Column(db.Integer, nullable=False)
    student_id = db.Column(db.Integer, nullable=False)
    note = db.Column(db.Text, nullable=False)

    def __init__(self, audit_id:int, audit_action:AuditAction, audit_datetime: DateTime, audit_issuer_id:Optional["int"], issuer_id:int, student_id:int, note:str):
        self.audit_id = audit_id
        self.audit_action = audit_action
        self.audit_datetime = audit_datetime
        self.audit_issuer_id = audit_issuer_id

        self.issuer_id = issuer_id
        self.student_id = student_id
        self.note = note

        self.datetime = DateTime.datetime.now()

    def to_dict(self):
        return {
            'audit_id': self.audit_id,
            'audit_action': self.audit_action,
            'audit_datetime': self.audit_datetime,
            'audit_issuer_id': self.audit_issuer_id,

            'id': self.id,
            'datetime': self.datetime,
            'issuer_id': self.issuer_id,
            'student_id': self.student_id,
            'note': self.note,
        }